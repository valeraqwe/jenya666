<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>"Спирт Плюс"</title>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-PKDQLHQV');</script>
    <!-- End Google Tag Manager -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Roboto:400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="./main.css">
    <script src="https://kit.fontawesome.com/cd8855ee2a.js" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="icon"
          href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🥂</text></svg>">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
    <link rel="stylesheet" type="text/css" href="slick/slick.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./js/scripts.js"></script>
</head>
<body>
        <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PKDQLHQV"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
<header class="header">
    <div class="site_title">
        <h3 class="site_title_color">"Спирт Плюс"</h3>
    </div>

    <div class="phone">
        <i class="fa fa-phone"></i>
        <span>
              <h3><a class="phone_number" href="tel: +38 (097) 477 29 17">+38 (068) 206 25 29</a></h3>
         <button>Замовити зворотній<br>дзвінок</button>
        </span>
    </div>

<div class="mymodal">
  <div class="overlay">
    <div class="content">
      <i class="fa fa-times close" aria-hidden="true"></i>

      <h3>Замовлення дзвінка</h3>
      <form class="telegram-form">
                    <input type="text" name="name" placeholder="ПІБ" autocomplete="off" Required/>
                    <input type="text" name="phone" placeholder="Телефон" autocomplete="off" Required/>
                    <textarea rows="5" name="message" placeholder="Ваш коментар"></textarea>
                    <button type="submit" class="hero-btn red-btn">ВІДПРАВИТИ</button>
                </form>
    </div>
  </div>
</div>
</header>
<script>
    //Создаем переменную, в которую сохраняем наше модальное окно
    var modal = $('.mymodal');

    //Функция устанавливает значение свойства display в то, которое указано в ее параметрах при вызове
    function setModal(display) {
        modal.css('display', display);
    }

    //Функция обрабатывает клик по кнопке "Оставить заявку"
    $('button').click(function () {
        setModal('block');
    });

    //Функция обрабатывает клик по кнопке "Закрыть"
    $('.close').click(function () {
        setModal('none');
    });

    //Функция обрабатывает клики по модальному окну, и, если клик не произошел не по блоку content и не по его дочерним элементам, то закрываем модальное окно
    $(modal).click(function (e) {
        var target = e.target;
        if (!($('.content').is(target)) && $('.content').has(target).length === 0) {
            setModal('none');
        }
    });

    //Если нажата клавиша ESC, то закрываем модальное окно
    $(document).keydown(function (e) {
        if (e.which == 27) {
            setModal('none');
        }
    });
</script>
<div class="slideshow-container">

    <div class="mySlides fade">
        <img src="images/Group%20239.png" style="width:100%">
    </div>

</div>
<br>

<div style="text-align:center">
    <span class="dot"></span>
    <span class="dot"></span>
</div>
<section class="facilities">
    <h1>Спирт</h1>
    <div class="row">
        <div class="facilities-col">
            <img src="images/Group%2031.png">
            <h3>Спирт</h3>
            <h3>"Екстра"</h3>
            <p>5л <span style="font-weight:bold;"> - 147грн/л =735грн</span></p>
            <p>10л <span style="font-weight:bold;"> - 142грн/л =1420грн</span></p>
            <p>20л <span style="font-weight:bold;"> - 140грн/л =2800грн</span></p>
            <p>60л <span style="font-weight:bold;"> - 138грн/л =8280грн</span></p>
            <p>100л <span style="font-weight:bold;"> - 136грн/л =13600грн</span></p>
            <p>200л <span style="font-weight:bold;"> - 134грн/л =26800грн</span></p>
            <p>600л - договірна</p>
            <a href="#id_form" class="hero-btn red-btn">Замовити</a>
        </div>
        <div class="facilities-col">
            <img src="images/Group%2032.png">
            <h3>Спирт</h3>
            <h3>"Люкс"</h3>
            <p>5л <span style="font-weight:bold;"> - 152грн/л =760грн</span></p>
            <p>10л <span style="font-weight:bold;"> - 150грн/л =1500грн</span></p>
            <p>20л <span style="font-weight:bold;"> - 149грн/л =2980грн</span></p>
            <p>60л <span style="font-weight:bold;"> - 147грн/л =8820грн</span></p>
            <p>100л <span style="font-weight:bold;"> - 146грн/л =14600грн</span></p>
            <p>200л <span style="font-weight:bold;"> - 143грн/л =28600грн</span></p>
            <p>600л - договірна</p>
            <a href="#id_form" class="hero-btn red-btn">Замовити</a>
        </div>
        <div class="facilities-col">
            <img src="images/Group%2033.png">
            <h3>Спирт</h3>
            <h3>"Альфа"</h3>
            <p>5л <span style="font-weight:bold;"> - 155грн/л =775грн</span></p>
            <p>10л <span style="font-weight:bold;"> - 153грн/л =1530грн</span></p>
            <p>20л <span style="font-weight:bold;"> - 150грн/л =3000грн</span></p>
            <p>60л <span style="font-weight:bold;"> - 148грн/л =8880грн</span></p>
            <p>100л <span style="font-weight:bold;"> - 147грн/л =14700грн</span></p>
            <p>200л <span style="font-weight:bold;"> - 145грн/л =29000грн</span></p>
            <p>600л - договірна</p>
            <a href="#id_form" class="hero-btn red-btn">Замовити</a>
        </div>
        <div class="facilities-col">
            <img src="images/Group%2023.png">
            <h3>Спирт</h3>
            <h3 class="sleza">"Пшенична сльоза"</h3>
            <p>5л <span style="font-weight:bold;"> - 163грн/л =815грн</span></p>
            <p>10л <span style="font-weight:bold;"> - 160грн/л =1600грн</span></p>
            <p>20л <span style="font-weight:bold;"> - 157грн/л =3140грн</span></p>
            <p>60л <span style="font-weight:bold;"> - 155грн/л =9300грн</span></p>
            <p>100л <span style="font-weight:bold;"> - 153грн/л =15300грн</span></p>
            <p>200л <span style="font-weight:bold;"> - 150грн/л =30000грн</span></p>
            <p>600л - договірна</p>
            <a href="#id_form" class="hero-btn red-btn">Замовити</a>
        </div>
        <div class="facilities-col">
            <img src="images/Group%2034.png">
            <h3>Спирт</h3>
            <h3>"Медичний"</h3>
            <p>5л <span style="font-weight:bold;"> - 170грн/л =850грн</span></p>
            <p>10л <span style="font-weight:bold;"> - 167грн/л =1670грн</span></p>
            <p>20л <span style="font-weight:bold;"> - 165грн/л =3300грн</span></p>
            <p>60л <span style="font-weight:bold;"> - 160грн/л =9600грн</span></p>
            <p>100л <span style="font-weight:bold;"> - 155грн/л =15500грн</span></p>
            <p>200л <span style="font-weight:bold;"> - 152грн/л =30400грн</span></p>
            <p>600л - договірна</p>
            <a href="#id_form" class="hero-btn red-btn">Замовити</a>
        </div>
    </div>
</section>




 <!--testimonials -->

<section class="testimonials">
    <h1>Що кажуть наші покупці:</h1>
    <div class="row">
        <div class="testimonial-col">
            <img src="images/kamaaa.jpg">
            <div>
                <p>Ціна хороша, якість спирту - вища! Дякую!</p>
                <h3>Галина, Київ</h3>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
        </div>
        <div class="testimonial-col">
            <img src="images/Donald_Trump.jpg">
            <div>
                <p>Спасибі що ви є. Надійно, швидко. Мені подобається!</p>
                <h3>Василь, Одеса</h3>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
        </div>
    </div>

</section>

 <!--blog page content -->
<section class="blog-content">

    <div class="row">
        <div class="blog-left">
            <h2>СПИРТ ПЛЮС</h2>
            <p>Завод виготовляє та продає спирт по території України.</p>
            <br>
            <p>Допомагають такі логістичні компанії як Нова пошта та Укрпошта. В наявності такі види:</p>
            <br>
            <p>"Медичний спирт" "Екстра спирт" "Альфа спирт" "Люкс спирт" та "Пшенична сльоза спирт" .</p>
            <br>
            <p>Виготовляємо лише етиловий спирт. У народі ще на нього говорять харчовий спирт. Мінімальне замовлення спирту 10 літрів.
            </p>
        </div>
        <div class="blog-right">
            <div id="id_form" class="comment-box">

                <h3>Оформити замовлення</h3>

                <form class="telegram-form">
                    <input type="text" name="name" placeholder="ПІБ" autocomplete="off" Required/>
                    <input type="text" name="phone" placeholder="Телефон" autocomplete="off" Required/>
                    <input type="text" name="sity" placeholder="Ваше місто" autocomplete="off" Required/>
                    <input type="text" name="oblast" placeholder="Ваша область" autocomplete="off" Required/>
                    <label> Який вид спирту?<br></label>
                    <select name="spirtname">
                        <option value="не вибрано">---</option>
                        <option value="Екстра">"Екстра"</option>
                        <option value="Люкс">"Люкс"</option>
                        <option value="Альфа">"Альфа"</option>
                        <option value="Пшенична сльоза">"Пшенична сльоза"</option>
                        <option value="Медичний">"Медичний"</option>
                    </select>
                    <label> Спосіб доставки<br></label>
                    <select name="delivery">
                        <option value="не вибрано">---</option>
                        <option value="Новая Почта">Нова Пошта</option>
                        <option value="Укрпочта">Укрпошта (вкажіть індекс в коментарі)</option>
                    </select>
                    <label> Відділення №:<br></label>
                    <input type="number" name="postnumber" placeholder="Номер відділення" autocomplete="off" value=""
                           min="1" max="9999" aria-required="true" aria-invalid="false" Required/>
                    <label>Спосіб оплати</label>
                    <select name="payment" Служба доставки>
                        <option value="При получении">При отриманні</option>
                        <option value="На карту">На карту</option>
                    </select>
                    <label>Скільки літрів? мінімальне замовлення 10 літрів</label>
                    <input type="number" name="litrs" placeholder="10" autocomplete="off" Required/>
                    <label> Передзвонити вам після оформлення?<br></label>
                     <select name="perezvon">
                        <option value="не вибрано">---</option>
                        <option value="Так">Так</option>
                        <option value="Ні">Ні</option>
                    </select>
                    <textarea rows="5" name="message" placeholder="Ваш коментар"></textarea>
                    <button type="submit" class="hero-btn red-btn">НАДІСЛАТИ</button>
                </form>
            </div>
        </div>
    </div>

</section>

 <!--footer -->


<section class="footer">
    <h4>Спирт плюс</h4>

    <p>2023</p>

</section>


 <!--JS!!! -->
<script>

    var navLinks = document.getElementById("navLinks");

    function showMenu() {
        navLinks.style.right = "0";
    }

    function hideMenu() {
        navLinks.style.right = "-200px";
    }

</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="./main.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="slick/slick.min.js"></script>
<script>
    let slideIndex = 0;
    showSlides();

    function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
        setTimeout(showSlides, 4500); // Change image every 4.5 seconds
    }
</script>

</body>
</html>

